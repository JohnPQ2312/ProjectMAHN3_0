alter session set "_ORACLE_SCRIPT" = true;

create user JPerez identified by "1234" ;

grant dba to JPerez;